import { MessageCircle } from "lucide-react";
import Pill from "@/components/ui/Pill";
import SpecularLink from "@/components/ui/SpecularLink";

export default function CtaProduk() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
      <div className="rounded-3xl bg-linear-to-r from-brand via-brand to-navy p-8 text-white sm:p-12">
        <Pill tone="dark" className="bg-white/15 text-white">
          Konsultasi Transaksi Resmi
        </Pill>
        <h2 className="type-h2 mt-4 max-w-md">
          Siap Mengenal Produk Kami Lebih Jauh?
        </h2>
        <p className="type-body mt-3 max-w-lg text-white/85">
          Diskusikan rencana analisa dan pemantauan pasar Anda bersama tim
          profesional berlisensi resmi BAPPEBTI.
        </p>

        <div className="mt-7 flex flex-wrap gap-3">
          <SpecularLink href="#" variant="light">
            <MessageCircle size={16} className="text-bull" /> Chat WhatsApp
          </SpecularLink>
          <SpecularLink href="/kontak" variant="ghost">
            Hubungi Kami
          </SpecularLink>
        </div>
      </div>
    </section>
  );
}