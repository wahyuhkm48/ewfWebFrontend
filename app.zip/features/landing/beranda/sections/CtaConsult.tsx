import { MessageCircle } from "lucide-react";
import SpecularLink from "@/components/ui/SpecularLink";
import { WHATSAPP_URL } from "@/features/landing/shared/data/contact";

export default function CtaConsult() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
      <div className="grid items-center gap-8 rounded-3xl bg-linear-to-r from-navy via-navy to-brand p-8 text-white sm:p-12 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <h2 className="type-h2">
            Punya Pertanyaan Seputar Perdagangan Berjangka?
            <span className="block">Tim Kami Siap Membantu.</span>
          </h2>
          <p className="type-body mt-3 max-w-xl text-white/80">
            Konsultasi gratis bersama wakil pialang berjangka profesional
            berlisensi resmi. Pelajari mekanisme pasar, risiko, dan tata cara
            transaksi dengan nyaman.
          </p>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
          <SpecularLink href={WHATSAPP_URL} variant="light">
            <MessageCircle size={16} className="text-bull" /> Chat WhatsApp Resmi
          </SpecularLink>
        </div>
      </div>
    </section>
  );
}